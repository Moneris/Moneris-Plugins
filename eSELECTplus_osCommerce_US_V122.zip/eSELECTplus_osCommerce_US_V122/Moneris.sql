create table moneris_orders (
	moneris_order_id	varchar(50) not null,
	osc_order_id		varchar(11),
	osc_session		varchar(32),
	f4l4			varchar(16),
	ref_num			varchar(18),
	resp_code		varchar(5),
	auth_code		varchar(8),
	trans_date		varchar(12),
	trans_time		varchar(10),
	trans_type		varchar(10),
	message			varchar(100),
	card_type		varchar(10),
	txn_num			varchar(20),
	avs_code		varchar(5),
	cvd_code		varchar(5),
	crypt_type		varchar(5),
	veres			varchar(5),
	pares			varchar(5),
	  CONSTRAINT mon_order_id PRIMARY KEY (moneris_order_id, trans_type)
);

